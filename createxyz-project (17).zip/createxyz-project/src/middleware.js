import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "3b1f29f8-cf71-4ae6-b783-e75d228e456a");
  requestHeaders.set("x-createxyz-project-group-id", "e5922899-4ad1-4c5f-88ca-3a00e5beaac9");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}