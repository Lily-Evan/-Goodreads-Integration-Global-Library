async function handler({ language, search, page = 1, limit = 20 }) {
  try {
    let queryString = "SELECT * FROM books WHERE 1=1";
    const values = [];
    let paramCount = 0;

    if (language) {
      paramCount++;
      queryString += ` AND language = $${paramCount}`;
      values.push(language);
    }

    if (search) {
      paramCount++;
      queryString += ` AND (LOWER(title) LIKE LOWER($${paramCount}) OR LOWER(author) LIKE LOWER($${paramCount}) OR LOWER(description) LIKE LOWER($${paramCount}))`;
      values.push(`%${search}%`);
    }

    queryString += " ORDER BY created_at DESC";

    const offset = (page - 1) * limit;
    paramCount++;
    queryString += ` LIMIT $${paramCount}`;
    values.push(limit);

    paramCount++;
    queryString += ` OFFSET $${paramCount}`;
    values.push(offset);

    const books = await sql(queryString, values);

    let countQueryString = "SELECT COUNT(*) as total FROM books WHERE 1=1";
    const countValues = [];
    let countParamCount = 0;

    if (language) {
      countParamCount++;
      countQueryString += ` AND language = $${countParamCount}`;
      countValues.push(language);
    }

    if (search) {
      countParamCount++;
      countQueryString += ` AND (LOWER(title) LIKE LOWER($${countParamCount}) OR LOWER(author) LIKE LOWER($${countParamCount}) OR LOWER(description) LIKE LOWER($${countParamCount}))`;
      countValues.push(`%${search}%`);
    }

    const countResult = await sql(countQueryString, countValues);
    const total = parseInt(countResult[0].total);

    return {
      books,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  } catch (error) {
    return { error: "Failed to fetch books" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}