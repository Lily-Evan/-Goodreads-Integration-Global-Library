async function handler({
  favoriteGenres = [],
  favoriteAuthors = [],
  booksRead = [],
  mood = "",
  languagePreference = "all",
  numberOfRecommendations = 5,
  additionalPreferences = "",
}) {
  try {
    if (numberOfRecommendations < 1 || numberOfRecommendations > 20) {
      return { error: "Number of recommendations must be between 1 and 20" };
    }

    let booksQuery = "SELECT * FROM books WHERE 1=1";
    const queryValues = [];
    let paramCount = 0;

    if (languagePreference && languagePreference !== "all") {
      paramCount++;
      booksQuery += ` AND language = $${paramCount}`;
      queryValues.push(languagePreference);
    }

    booksQuery += " ORDER BY created_at DESC LIMIT 100";

    const availableBooks = await sql(booksQuery, queryValues);

    if (availableBooks.length === 0) {
      return {
        error: "No books available in the database for the specified language",
      };
    }

    const booksList = availableBooks.map((book) => ({
      title: book.title,
      author: book.author,
      description: book.description || "No description available",
      language: book.language,
      publication_year: book.publication_year,
      id: book.id,
    }));

    const userPreferences = {
      favoriteGenres:
        favoriteGenres.length > 0
          ? favoriteGenres.join(", ")
          : "No specific genres mentioned",
      favoriteAuthors:
        favoriteAuthors.length > 0
          ? favoriteAuthors.join(", ")
          : "No specific authors mentioned",
      booksRead:
        booksRead.length > 0 ? booksRead.join(", ") : "No books mentioned",
      mood: mood || "No specific mood mentioned",
      languagePreference:
        languagePreference === "all" ? "Any language" : languagePreference,
      additionalPreferences:
        additionalPreferences || "No additional preferences",
    };

    const prompt = `You are a professional book recommendation AI. Based on the user's preferences below, recommend ${numberOfRecommendations} books from the provided book list.

User Preferences:
- Favorite Genres: ${userPreferences.favoriteGenres}
- Favorite Authors: ${userPreferences.favoriteAuthors}
- Books Already Read: ${userPreferences.booksRead}
- Current Mood: ${userPreferences.mood}
- Language Preference: ${userPreferences.languagePreference}
- Additional Preferences: ${userPreferences.additionalPreferences}

Available Books:
${JSON.stringify(booksList, null, 2)}

Please respond with a JSON object containing exactly ${numberOfRecommendations} recommendations. Each recommendation should include:
- bookId: The ID of the recommended book
- title: The book title
- author: The book author
- reason: A personalized explanation (2-3 sentences) of why this book matches the user's preferences
- matchScore: A score from 1-10 indicating how well this book matches the user's preferences

Format your response as:
{
  "recommendations": [
    {
      "bookId": number,
      "title": "string",
      "author": "string", 
      "reason": "string",
      "matchScore": number
    }
  ]
}

Important: Only recommend books that exist in the provided book list. If there are fewer suitable books than requested, recommend as many as possible. Provide thoughtful, personalized reasons based on the user's specific preferences.`;

    const chatResponse = await fetch("/integrations/chat-gpt/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
        model: "gpt-4",
        temperature: 0.7,
      }),
    });

    if (!chatResponse.ok) {
      return { error: "Failed to get AI recommendations" };
    }

    const chatData = await chatResponse.json();

    if (
      !chatData.choices ||
      !chatData.choices[0] ||
      !chatData.choices[0].message
    ) {
      return { error: "Invalid response from AI service" };
    }

    let aiResponse;
    try {
      aiResponse = JSON.parse(chatData.choices[0].message.content);
    } catch (parseError) {
      return { error: "Failed to parse AI recommendations" };
    }

    if (
      !aiResponse.recommendations ||
      !Array.isArray(aiResponse.recommendations)
    ) {
      return { error: "Invalid recommendation format from AI" };
    }

    const validRecommendations = [];

    for (const rec of aiResponse.recommendations) {
      const book = availableBooks.find((b) => b.id === rec.bookId);
      if (book) {
        validRecommendations.push({
          bookId: book.id,
          title: book.title,
          author: book.author,
          description: book.description,
          language: book.language,
          publication_year: book.publication_year,
          image_url: book.image_url,
          source_url: book.source_url,
          reason: rec.reason || "Recommended based on your preferences",
          matchScore: rec.matchScore || 5,
        });
      }
    }

    if (validRecommendations.length === 0) {
      return {
        error: "No suitable recommendations found",
        suggestions: "Try adjusting your preferences or language settings",
      };
    }

    validRecommendations.sort((a, b) => b.matchScore - a.matchScore);

    return {
      success: true,
      recommendations: validRecommendations,
      totalRecommendations: validRecommendations.length,
      userPreferences: userPreferences,
      message: `Found ${validRecommendations.length} personalized book recommendations based on your preferences`,
    };
  } catch (error) {
    return { error: "Failed to generate book recommendations" };
  }
}
export async function POST(request) {
  return handler(await request.json());
}