async function handler({
  urls = [
    "https://www.goodreads.com/list/show/1.Best_Books_Ever",
    "https://www.goodreads.com/book/popular_by_date/2024",
    "https://www.goodreads.com/genres/fiction",
  ],
  maxBooksPerUrl = 20,
  language = "en",
}) {
  try {
    const scrapedBooks = [];
    const errors = [];

    for (const url of urls) {
      try {
        const response = await fetch("/integrations/web-scraping/post", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            url: url,
            getText: false,
          }),
        });

        if (!response.ok) {
          errors.push(`Failed to fetch ${url}: ${response.status}`);
          continue;
        }

        const html = await response.text();
        const books = extractBooksFromHtml(html, url);

        for (const book of books.slice(0, maxBooksPerUrl)) {
          if (book.title && book.author) {
            const existingBooks = await sql(
              "SELECT id FROM books WHERE LOWER(title) = LOWER($1) AND LOWER(author) = LOWER($2)",
              [book.title, book.author]
            );

            if (existingBooks.length === 0) {
              const result = await sql(
                `INSERT INTO books (title, author, description, language, publication_year, isbn, image_url, source_url) 
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) 
                 RETURNING *`,
                [
                  book.title,
                  book.author,
                  book.description,
                  language,
                  book.publication_year,
                  book.isbn,
                  book.image_url,
                  book.source_url || url,
                ]
              );

              scrapedBooks.push(result[0]);
            }
          }
        }
      } catch (urlError) {
        errors.push(`Error processing ${url}: ${urlError.message}`);
      }
    }

    return {
      success: true,
      totalScraped: scrapedBooks.length,
      scrapedBooks,
      urlsProcessed: urls.length,
      errors: errors.length > 0 ? errors : undefined,
    };
  } catch (error) {
    return { error: "Failed to scrape Goodreads books" };
  }
}

function extractBooksFromHtml(html, sourceUrl) {
  const books = [];

  const bookPatterns = [
    /<div[^>]*class="[^"]*bookTitle[^"]*"[^>]*>.*?<\/div>/gis,
    /<tr[^>]*itemtype="http:\/\/schema\.org\/Book"[^>]*>.*?<\/tr>/gis,
    /<div[^>]*class="[^"]*elementList[^"]*"[^>]*>.*?<\/div>/gis,
    /<article[^>]*class="[^"]*BookListItem[^"]*"[^>]*>.*?<\/article>/gis,
  ];

  for (const pattern of bookPatterns) {
    const matches = html.match(pattern) || [];

    for (const match of matches) {
      const book = extractBookDetails(match, sourceUrl);
      if (book.title && book.author) {
        books.push(book);
      }
    }
  }

  if (books.length === 0) {
    const fallbackBooks = extractFallbackBooks(html, sourceUrl);
    books.push(...fallbackBooks);
  }

  return books;
}

function extractBookDetails(htmlBlock, sourceUrl) {
  const book = {
    title: "",
    author: "",
    description: "",
    publication_year: null,
    isbn: null,
    image_url: null,
    source_url: sourceUrl,
  };

  const titlePatterns = [
    /<a[^>]*class="[^"]*bookTitle[^"]*"[^>]*>(.*?)<\/a>/i,
    /<h3[^>]*class="[^"]*gr-h3[^"]*"[^>]*>.*?<a[^>]*>(.*?)<\/a>/i,
    /<span[^>]*itemprop="name"[^>]*>(.*?)<\/span>/i,
    /<a[^>]*title="([^"]*)"[^>]*class="[^"]*bookTitle/i,
  ];

  for (const pattern of titlePatterns) {
    const match = htmlBlock.match(pattern);
    if (match) {
      book.title = cleanText(match[1]);
      break;
    }
  }

  const authorPatterns = [
    /<a[^>]*class="[^"]*authorName[^"]*"[^>]*>(.*?)<\/a>/i,
    /<span[^>]*itemprop="author"[^>]*>.*?<a[^>]*>(.*?)<\/a>/i,
    /<div[^>]*class="[^"]*authorName[^"]*"[^>]*>(.*?)<\/div>/i,
    /by\s+<a[^>]*>(.*?)<\/a>/i,
  ];

  for (const pattern of authorPatterns) {
    const match = htmlBlock.match(pattern);
    if (match) {
      book.author = cleanText(match[1]);
      break;
    }
  }

  const descriptionPatterns = [
    /<span[^>]*class="[^"]*readable[^"]*"[^>]*>(.*?)<\/span>/is,
    /<div[^>]*class="[^"]*description[^"]*"[^>]*>(.*?)<\/div>/is,
    /<span[^>]*style="display:none"[^>]*>(.*?)<\/span>/is,
  ];

  for (const pattern of descriptionPatterns) {
    const match = htmlBlock.match(pattern);
    if (match) {
      book.description = cleanText(match[1]).substring(0, 1000);
      break;
    }
  }

  const yearMatch =
    htmlBlock.match(/published[^>]*(\d{4})/i) ||
    htmlBlock.match(/\b(19|20)\d{2}\b/);
  if (yearMatch) {
    book.publication_year = parseInt(yearMatch[1] || yearMatch[0]);
  }

  const isbnMatch = htmlBlock.match(/ISBN[:\s]*(\d{10}|\d{13})/i);
  if (isbnMatch) {
    book.isbn = isbnMatch[1];
  }

  const imagePatterns = [
    /<img[^>]*src="([^"]*)"[^>]*class="[^"]*bookCover/i,
    /<img[^>]*class="[^"]*bookCover[^"]*"[^>]*src="([^"]*)"/i,
    /<img[^>]*src="([^"]*book[^"]*)"/i,
  ];

  for (const pattern of imagePatterns) {
    const match = htmlBlock.match(pattern);
    if (match && match[1] && !match[1].includes("nophoto")) {
      book.image_url = match[1].startsWith("http")
        ? match[1]
        : `https:${match[1]}`;
      break;
    }
  }

  return book;
}

function extractFallbackBooks(html, sourceUrl) {
  const books = [];

  const titleMatches =
    html.match(/<a[^>]*href="\/book\/show\/[^"]*"[^>]*>([^<]+)<\/a>/gi) || [];
  const authorMatches =
    html.match(/<a[^>]*class="[^"]*authorName[^"]*"[^>]*>([^<]+)<\/a>/gi) || [];

  const minLength = Math.min(titleMatches.length, authorMatches.length);

  for (let i = 0; i < minLength && i < 10; i++) {
    const titleMatch = titleMatches[i].match(/>([^<]+)<\/a>/);
    const authorMatch = authorMatches[i].match(/>([^<]+)<\/a>/);

    if (titleMatch && authorMatch) {
      books.push({
        title: cleanText(titleMatch[1]),
        author: cleanText(authorMatch[1]),
        description: "",
        publication_year: null,
        isbn: null,
        image_url: null,
        source_url: sourceUrl,
      });
    }
  }

  return books;
}

function cleanText(text) {
  if (!text) return "";

  return text
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}
export async function POST(request) {
  return handler(await request.json());
}