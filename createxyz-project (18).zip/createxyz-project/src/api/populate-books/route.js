async function handler() {
  try {
    const books = [
      // Greek Literature - Classics
      {
        title: "Ζορμπάς",
        author: "Νίκος Καζαντζάκης",
        description:
          "Το αριστούργημα του Καζαντζάκη που παρουσιάζει τη φιλοσοφία ζωής μέσα από τον χαρακτήρα του Αλέξη Ζορμπά. Μια ιστορία για την ελευθερία, τη χαρά της ζωής και την ανθρώπινη φύση.",
        language: "el",
        publication_year: 1946,
        isbn: "9789600400021",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
      {
        title: "Η Ζωή εν Τάφω",
        author: "Στρατής Μυριβήλης",
        description:
          "Ένα από τα σημαντικότερα έργα της νεοελληνικής λογοτεχνίας που περιγράφει τις φρικαλεότητες του πολέμου μέσα από τα μάτια ενός στρατιώτη.",
        language: "el",
        publication_year: 1924,
        isbn: "9789600400038",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Το Αξιόν Εστί",
        author: "Οδυσσέας Ελύτης",
        description:
          "Το μεγάλο ποιητικό έργο του Νομπελίστα Οδυσσέα Ελύτη, ένας ύμνος στην Ελλάδα και τον ελληνικό πολιτισμό.",
        language: "el",
        publication_year: 1959,
        isbn: "9789600400045",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "Η Μαγική Πόλη",
        author: "Μ. Καραγάτσης",
        description:
          "Ένα κλασικό έργο της νεοελληνικής πεζογραφίας που εξερευνά τις ανθρώπινες σχέσεις και τα κοινωνικά προβλήματα.",
        language: "el",
        publication_year: 1938,
        isbn: "9789600400052",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "Το Καπλάνι της Βιτρίνας",
        author: "Άλκη Ζέη",
        description:
          "Ένα αγαπημένο παιδικό βιβλίο που διηγείται την ιστορία ενός καπλάνι που ζωντανεύει από μια βιτρίνα παιχνιδιών.",
        language: "el",
        publication_year: 1963,
        isbn: "9789600400069",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // Modern Greek Literature
      {
        title: "Η Δασκάλα με τα Χρυσά Μάτια",
        author: "Στρατής Τσίρκας",
        description:
          "Ένα συγκινητικό μυθιστόρημα για την αγάπη, την απώλεια και την ανθρώπινη αξιοπρέπεια στη μεταπολεμική Ελλάδα.",
        language: "el",
        publication_year: 1954,
        isbn: "9789600400076",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
      {
        title: "Ο Χριστός Ξανασταυρώνεται",
        author: "Νίκος Καζαντζάκης",
        description:
          "Ένα δυνατό έργο που εξετάζει τη θρησκεία, την πολιτική και την ανθρώπινη φύση μέσα από την ιστορία ενός χωριού.",
        language: "el",
        publication_year: 1954,
        isbn: "9789600400083",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Η Πλατεία των Ηρώων",
        author: "Στρατής Τσίρκας",
        description:
          "Μια επική τριλογία που καλύπτει την περίοδο από τον Β' Παγκόσμιο Πόλεμο έως τον Εμφύλιο.",
        language: "el",
        publication_year: 1960,
        isbn: "9789600400090",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },

      // English Literature - Classics
      {
        title: "1984",
        author: "George Orwell",
        description:
          "A dystopian social science fiction novel that explores themes of totalitarianism, surveillance, and individual freedom in a society dominated by Big Brother.",
        language: "en",
        publication_year: 1949,
        isbn: "9780451524935",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Animal Farm",
        author: "George Orwell",
        description:
          "An allegorical novella that reflects events leading up to the Russian Revolution and the Stalinist era of the Soviet Union.",
        language: "en",
        publication_year: 1945,
        isbn: "9780451526342",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Pride and Prejudice",
        author: "Jane Austen",
        description:
          "A romantic novel that critiques the British landed gentry at the end of the 18th century, following Elizabeth Bennet and Mr. Darcy.",
        language: "en",
        publication_year: 1813,
        isbn: "9780141439518",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
      {
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        description:
          "A novel about racial injustice and childhood innocence in the American South, told through the eyes of Scout Finch.",
        language: "en",
        publication_year: 1960,
        isbn: "9780061120084",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        description:
          "A critique of the American Dream set in the Jazz Age, following Jay Gatsby's pursuit of Daisy Buchanan.",
        language: "en",
        publication_year: 1925,
        isbn: "9780743273565",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // Stephen King
      {
        title: "The Shining",
        author: "Stephen King",
        description:
          "A horror novel about Jack Torrance, who becomes winter caretaker at the isolated Overlook Hotel with his family, where supernatural forces influence him toward violence.",
        language: "en",
        publication_year: 1977,
        isbn: "9780307743657",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "It",
        author: "Stephen King",
        description:
          "A horror novel about seven children who are terrorized by an entity that exploits the fears and phobias of its victims to disguise itself while hunting its prey.",
        language: "en",
        publication_year: 1986,
        isbn: "9781501142970",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Carrie",
        author: "Stephen King",
        description:
          "King's first published novel about a teenage girl with telekinetic powers who is bullied at school and abused at home.",
        language: "en",
        publication_year: 1974,
        isbn: "9780307743664",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
      {
        title: "The Stand",
        author: "Stephen King",
        description:
          "A post-apocalyptic dark fantasy novel about a pandemic that wipes out most of humanity and the subsequent struggle between good and evil.",
        language: "en",
        publication_year: 1978,
        isbn: "9780307743688",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },

      // J.K. Rowling - Harry Potter Series
      {
        title: "Harry Potter and the Philosopher's Stone",
        author: "J.K. Rowling",
        description:
          "The first novel in the Harry Potter series, introducing the young wizard Harry Potter and his adventures at Hogwarts School of Witchcraft and Wizardry.",
        language: "en",
        publication_year: 1997,
        isbn: "9780747532699",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "Harry Potter and the Chamber of Secrets",
        author: "J.K. Rowling",
        description:
          "The second novel in the Harry Potter series, where Harry returns to Hogwarts and faces the mystery of the Chamber of Secrets.",
        language: "en",
        publication_year: 1998,
        isbn: "9780747538493",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },
      {
        title: "Harry Potter and the Prisoner of Azkaban",
        author: "J.K. Rowling",
        description:
          "The third novel in the Harry Potter series, introducing Sirius Black and exploring Harry's family history.",
        language: "en",
        publication_year: 1999,
        isbn: "9780747542155",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Harry Potter and the Goblet of Fire",
        author: "J.K. Rowling",
        description:
          "The fourth novel in the Harry Potter series, featuring the Triwizard Tournament and the return of Lord Voldemort.",
        language: "en",
        publication_year: 2000,
        isbn: "9780747546245",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },

      // Agatha Christie
      {
        title: "Murder on the Orient Express",
        author: "Agatha Christie",
        description:
          "A detective novel featuring Hercule Poirot investigating a murder aboard the famous Orient Express train.",
        language: "en",
        publication_year: 1934,
        isbn: "9780062693662",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
      {
        title: "And Then There Were None",
        author: "Agatha Christie",
        description:
          "A mystery novel about ten strangers invited to an island where they are killed one by one according to a sinister nursery rhyme.",
        language: "en",
        publication_year: 1939,
        isbn: "9780062073488",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "The Murder of Roger Ackroyd",
        author: "Agatha Christie",
        description:
          "A Hercule Poirot mystery that revolutionized the detective genre with its innovative narrative technique.",
        language: "en",
        publication_year: 1926,
        isbn: "9780062073556",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },

      // French Literature
      {
        title: "Le Petit Prince",
        author: "Antoine de Saint-Exupéry",
        description:
          "Un conte poétique et philosophique qui raconte l'histoire d'un petit prince qui voyage de planète en planète.",
        language: "fr",
        publication_year: 1943,
        isbn: "9782070408504",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },
      {
        title: "Les Misérables",
        author: "Victor Hugo",
        description:
          "Un roman historique qui suit la vie de Jean Valjean et dépeint la société française du 19ème siècle.",
        language: "fr",
        publication_year: 1862,
        isbn: "9782070409228",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "L'Étranger",
        author: "Albert Camus",
        description:
          "Un roman existentialiste qui explore l'absurdité de la condition humaine à travers l'histoire de Meursault.",
        language: "fr",
        publication_year: 1942,
        isbn: "9782070360024",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Madame Bovary",
        author: "Gustave Flaubert",
        description:
          "L'histoire d'Emma Bovary, une femme qui rêve d'une vie plus passionnante que celle qu'elle mène.",
        language: "fr",
        publication_year: 1857,
        isbn: "9782070409235",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },

      // Spanish Literature
      {
        title: "Don Quijote de la Mancha",
        author: "Miguel de Cervantes",
        description:
          "La obra maestra de la literatura española que narra las aventuras del ingenioso hidalgo Don Quijote y su escudero Sancho Panza.",
        language: "es",
        publication_year: 1605,
        isbn: "9788437604947",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "Cien años de soledad",
        author: "Gabriel García Márquez",
        description:
          "Una novela de realismo mágico que cuenta la historia de la familia Buendía a lo largo de siete generaciones.",
        language: "es",
        publication_year: 1967,
        isbn: "9788437604954",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "La Casa de Bernarda Alba",
        author: "Federico García Lorca",
        description:
          "Una obra teatral que retrata la opresión de las mujeres en la España rural del siglo XX.",
        language: "es",
        publication_year: 1936,
        isbn: "9788437604961",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // German Literature
      {
        title: "Die Verwandlung",
        author: "Franz Kafka",
        description:
          "Eine Erzählung über Gregor Samsa, der sich eines Morgens in ein riesiges Ungeziefer verwandelt findet.",
        language: "de",
        publication_year: 1915,
        isbn: "9783596294312",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Faust",
        author: "Johann Wolfgang von Goethe",
        description:
          "Das berühmte Drama über den Gelehrten Faust, der einen Pakt mit dem Teufel eingeht.",
        language: "de",
        publication_year: 1808,
        isbn: "9783596294329",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Der Prozess",
        author: "Franz Kafka",
        description:
          "Ein Roman über Josef K., der ohne ersichtlichen Grund verhaftet und vor Gericht gestellt wird.",
        language: "de",
        publication_year: 1925,
        isbn: "9783596294336",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },

      // Science Fiction
      {
        title: "Dune",
        author: "Frank Herbert",
        description:
          "A science fiction epic set on the desert planet Arrakis, following Paul Atreides and his journey to fulfill his destiny.",
        language: "en",
        publication_year: 1965,
        isbn: "9780441172719",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "Foundation",
        author: "Isaac Asimov",
        description:
          "The first novel in the Foundation series, exploring the fall and rise of galactic civilizations through psychohistory.",
        language: "en",
        publication_year: 1951,
        isbn: "9780553293357",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "Neuromancer",
        author: "William Gibson",
        description:
          "A cyberpunk novel that follows a washed-up computer hacker hired for one last job in cyberspace.",
        language: "en",
        publication_year: 1984,
        isbn: "9780441569595",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // Philosophy
      {
        title: "The Republic",
        author: "Plato",
        description:
          "A Socratic dialogue concerning justice and the ideal state, one of the most influential works in Western philosophy.",
        language: "en",
        publication_year: -380,
        isbn: "9780140449143",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Nicomachean Ethics",
        author: "Aristotle",
        description:
          "Aristotle's work on ethics, exploring the nature of virtue, happiness, and the good life.",
        language: "en",
        publication_year: -340,
        isbn: "9780140449495",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Meditations",
        author: "Marcus Aurelius",
        description:
          "Personal writings by the Roman Emperor Marcus Aurelius on Stoic philosophy and self-improvement.",
        language: "en",
        publication_year: 180,
        isbn: "9780140449334",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },

      // History
      {
        title: "Sapiens: A Brief History of Humankind",
        author: "Yuval Noah Harari",
        description:
          "An exploration of how Homo sapiens came to dominate the world, examining the cognitive, agricultural, and scientific revolutions.",
        language: "en",
        publication_year: 2011,
        isbn: "9780062316097",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "The Guns of August",
        author: "Barbara Tuchman",
        description:
          "A detailed account of the first month of World War I, examining the events that led to the Great War.",
        language: "en",
        publication_year: 1962,
        isbn: "9780345476098",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "A People's History of the United States",
        author: "Howard Zinn",
        description:
          "An alternative history of the United States told from the perspective of ordinary people rather than political leaders.",
        language: "en",
        publication_year: 1980,
        isbn: "9780062397348",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // Children's Books
      {
        title: "Charlotte's Web",
        author: "E.B. White",
        description:
          "The story of a pig named Wilbur and his friendship with a barn spider named Charlotte who saves his life.",
        language: "en",
        publication_year: 1952,
        isbn: "9780064400558",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Where the Wild Things Are",
        author: "Maurice Sendak",
        description:
          "The story of Max, who sails to an island populated by creatures known as Wild Things.",
        language: "en",
        publication_year: 1963,
        isbn: "9780064431781",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "The Cat in the Hat",
        author: "Dr. Seuss",
        description:
          "A beloved children's book about a mischievous cat who visits two children on a rainy day.",
        language: "en",
        publication_year: 1957,
        isbn: "9780394800011",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },

      // Modern Fiction
      {
        title: "The Kite Runner",
        author: "Khaled Hosseini",
        description:
          "A story of friendship, guilt, and redemption set against the backdrop of Afghanistan's tumultuous history.",
        language: "en",
        publication_year: 2003,
        isbn: "9781594631931",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "Life of Pi",
        author: "Yann Martel",
        description:
          "The story of Pi Patel, a young man who survives 227 days stranded on a lifeboat with a Bengal tiger.",
        language: "en",
        publication_year: 2001,
        isbn: "9780156027328",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "The Handmaid's Tale",
        author: "Margaret Atwood",
        description:
          "A dystopian novel set in a totalitarian society where women are subjugated and used for reproductive purposes.",
        language: "en",
        publication_year: 1985,
        isbn: "9780385490818",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // Science and Nature
      {
        title: "A Brief History of Time",
        author: "Stephen Hawking",
        description:
          "An exploration of cosmology and theoretical physics, making complex scientific concepts accessible to general readers.",
        language: "en",
        publication_year: 1988,
        isbn: "9780553380163",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "The Origin of Species",
        author: "Charles Darwin",
        description:
          "Darwin's groundbreaking work on evolution and natural selection that revolutionized biology.",
        language: "en",
        publication_year: 1859,
        isbn: "9780140436310",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "Silent Spring",
        author: "Rachel Carson",
        description:
          "A groundbreaking environmental science book that launched the modern environmental movement.",
        language: "en",
        publication_year: 1962,
        isbn: "9780618249060",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },

      // Additional Greek Books
      {
        title: "Το Τρίτο Στεφάνι",
        author: "Κώστας Ταχτσής",
        description:
          "Ένα σημαντικό έργο της μεταπολεμικής ελληνικής λογοτεχνίας που εξερευνά θέματα ταυτότητας και κοινωνικής αλλαγής.",
        language: "el",
        publication_year: 1962,
        isbn: "9789600400107",
        image_url:
          "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
      },
      {
        title: "Η Γενιά του '30",
        author: "Γιάννης Ρίτσος",
        description:
          "Συλλογή ποιημάτων από έναν από τους σημαντικότερους Έλληνες ποιητές του 20ού αιώνα.",
        language: "el",
        publication_year: 1935,
        isbn: "9789600400114",
        image_url:
          "https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400",
      },
      {
        title: "Ο Παπαδιαμάντης",
        author: "Αλέξανδρος Παπαδιαμάντης",
        description:
          "Συλλογή διηγημάτων από τον 'άγιο των ελληνικών γραμμάτων' που απεικονίζουν τη ζωή στη Σκιάθο.",
        language: "el",
        publication_year: 1890,
        isbn: "9789600400121",
        image_url:
          "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400",
      },

      // More International Bestsellers
      {
        title: "The Da Vinci Code",
        author: "Dan Brown",
        description:
          "A mystery thriller that follows symbologist Robert Langdon as he investigates a murder in the Louvre Museum.",
        language: "en",
        publication_year: 2003,
        isbn: "9780307474278",
        image_url:
          "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400",
      },
      {
        title: "Gone Girl",
        author: "Gillian Flynn",
        description:
          "A psychological thriller about a marriage gone terribly wrong when Amy Dunne disappears on her fifth wedding anniversary.",
        language: "en",
        publication_year: 2012,
        isbn: "9780307588364",
        image_url:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
      },
      {
        title: "The Girl with the Dragon Tattoo",
        author: "Stieg Larsson",
        description:
          "A crime thriller featuring journalist Mikael Blomkvist and hacker Lisbeth Salander investigating a wealthy family's dark secrets.",
        language: "en",
        publication_year: 2005,
        isbn: "9780307949486",
        image_url:
          "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400",
      },
    ];

    let addedCount = 0;
    let skippedCount = 0;
    const errors = [];

    for (const book of books) {
      try {
        const existingBooks = await sql(
          "SELECT id FROM books WHERE LOWER(title) = LOWER($1) AND LOWER(author) = LOWER($2)",
          [book.title, book.author]
        );

        if (existingBooks.length === 0) {
          await sql(
            `INSERT INTO books (title, author, description, language, publication_year, isbn, image_url, source_url) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
            [
              book.title,
              book.author,
              book.description,
              book.language,
              book.publication_year,
              book.isbn,
              book.image_url,
              null,
            ]
          );
          addedCount++;
        } else {
          skippedCount++;
        }
      } catch (error) {
        errors.push(
          `Failed to add "${book.title}" by ${book.author}: ${error.message}`
        );
      }
    }

    return {
      success: true,
      message: `Database population completed successfully!`,
      stats: {
        totalProcessed: books.length,
        added: addedCount,
        skipped: skippedCount,
        errors: errors.length,
      },
      details: {
        addedBooks: addedCount,
        skippedDuplicates: skippedCount,
        errorCount: errors.length,
        errors: errors.length > 0 ? errors.slice(0, 10) : [],
      },
    };
  } catch (error) {
    return {
      success: false,
      error: "Failed to populate database",
      details: error.message,
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}