"use client";
import React from "react";

function MainComponent() {
  const [books, setBooks] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);
  const [searchTerm, setSearchTerm] = React.useState("");
  const [selectedLanguage, setSelectedLanguage] = React.useState("all");
  const [currentPage, setCurrentPage] = React.useState(1);
  const [pagination, setPagination] = React.useState(null);
  const [isSearching, setIsSearching] = React.useState(false);
  const [isScrapingGoodreads, setIsScrapingGoodreads] = React.useState(false);

  const loadBooks = React.useCallback(
    async (page = 1, search = "", language = "all") => {
      try {
        setLoading(true);
        const params = {
          page,
          limit: 12,
          ...(search && { search }),
          ...(language !== "all" && { language }),
        };

        const response = await fetch("/api/books", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(params),
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch books: ${response.status}`);
        }

        const data = await response.json();

        if (data.error) {
          throw new Error(data.error);
        }

        setBooks(data.books || []);
        setPagination(data.pagination);
      } catch (err) {
        console.error(err);
        setError("Could not load books");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const searchNewBooks = React.useCallback(async () => {
    try {
      setIsSearching(true);
      const queries = [
        "new books 2024",
        "bestseller books 2024",
        "popular fiction 2024",
        "award winning books 2024",
      ];

      for (const query of queries) {
        const language = "en";

        const response = await fetch("/api/books/search", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ query, language, maxResults: 5 }),
        });

        if (response.ok) {
          const data = await response.json();
          console.log(`Added ${data.totalAdded} new books for query: ${query}`);
        }
      }

      await loadBooks(currentPage, searchTerm, selectedLanguage);
    } catch (err) {
      console.error("Error searching for new books:", err);
    } finally {
      setIsSearching(false);
    }
  }, [currentPage, searchTerm, selectedLanguage, loadBooks]);

  const scrapeGoodreadsBooks = React.useCallback(async () => {
    try {
      setIsScrapingGoodreads(true);

      const response = await fetch("/api/scrape-goodreads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          urls: [
            "https://www.goodreads.com/list/show/1.Best_Books_Ever",
            "https://www.goodreads.com/book/popular_by_date/2024",
            "https://www.goodreads.com/genres/fiction",
            "https://www.goodreads.com/genres/mystery",
            "https://www.goodreads.com/genres/romance",
          ],
          maxBooksPerUrl: 15,
          language: "en",
        }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log(`Scraped ${data.totalScraped} books from Goodreads`);

        // Refresh the books list
        await loadBooks(currentPage, searchTerm, selectedLanguage);
      } else {
        throw new Error(`Failed to scrape Goodreads: ${response.status}`);
      }
    } catch (err) {
      console.error("Error scraping Goodreads:", err);
      setError("Could not scrape books from Goodreads");
    } finally {
      setIsScrapingGoodreads(false);
    }
  }, [currentPage, searchTerm, selectedLanguage, loadBooks]);

  React.useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  const handleSearch = React.useCallback(
    (e) => {
      e.preventDefault();
      setCurrentPage(1);
      loadBooks(1, searchTerm, selectedLanguage);
    },
    [searchTerm, selectedLanguage, loadBooks]
  );

  const handleLanguageChange = React.useCallback(
    (language) => {
      setSelectedLanguage(language);
      setCurrentPage(1);
      loadBooks(1, searchTerm, language);
    },
    [searchTerm, loadBooks]
  );

  const handlePageChange = React.useCallback(
    (page) => {
      setCurrentPage(page);
      loadBooks(page, searchTerm, selectedLanguage);
    },
    [searchTerm, selectedLanguage, loadBooks]
  );

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
          <div className="text-red-500 text-6xl mb-4">📚</div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            Something went wrong
          </h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            Try again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-800 font-serif">
                📚 Global Library
              </h1>
              <p className="text-gray-600 mt-2">
                Books from around the world - Updated daily with new titles
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="/ai-recommendations"
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all duration-200 flex items-center gap-2 text-center justify-center"
              >
                🤖 AI Book Recommendations
              </a>
              <button
                onClick={scrapeGoodreadsBooks}
                disabled={isScrapingGoodreads}
                className="bg-orange-500 text-white px-6 py-3 rounded-lg hover:bg-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isScrapingGoodreads ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                    Scraping Goodreads...
                  </>
                ) : (
                  <>📖 Import from Goodreads</>
                )}
              </button>
              <button
                onClick={searchNewBooks}
                disabled={isSearching}
                className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isSearching ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                    Finding new books...
                  </>
                ) : (
                  <>🔄 Refresh Books</>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Search and Filters */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <form
            onSubmit={handleSearch}
            className="flex flex-col md:flex-row gap-4"
          >
            <div className="flex-1">
              <input
                type="text"
                placeholder="Search books, authors..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={selectedLanguage}
                onChange={(e) => handleLanguageChange(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Languages</option>
                <option value="en">English</option>
                <option value="el">Greek</option>
                <option value="fr">French</option>
                <option value="es">Spanish</option>
                <option value="de">German</option>
              </select>
              <button
                type="submit"
                className="bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
              >
                🔍 Search
              </button>
            </div>
          </form>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
            <span className="ml-3 text-lg text-gray-600">Loading books...</span>
          </div>
        )}

        {/* Books Grid */}
        {!loading && books.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {books.map((book) => (
                <div
                  key={book.id}
                  className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden"
                >
                  <div className="h-48 bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                    {book.image_url ? (
                      <img
                        src={book.image_url}
                        alt={book.title}
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          e.target.style.display = "none";
                          e.target.nextSibling.style.display = "flex";
                        }}
                      />
                    ) : null}
                    <div
                      className="text-6xl text-gray-400"
                      style={{ display: book.image_url ? "none" : "flex" }}
                    >
                      📖
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg text-gray-800 mb-2 line-clamp-2">
                      {book.title}
                    </h3>
                    <p className="text-blue-600 font-medium mb-2">
                      {book.author}
                    </p>
                    {book.description && (
                      <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                        {book.description}
                      </p>
                    )}
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span className="bg-gray-100 px-2 py-1 rounded">
                        {book.language === "el"
                          ? "🇬🇷 Greek"
                          : book.language === "en"
                          ? "🇺🇸 English"
                          : book.language === "fr"
                          ? "🇫🇷 French"
                          : book.language === "es"
                          ? "🇪🇸 Spanish"
                          : book.language === "de"
                          ? "🇩🇪 German"
                          : book.language}
                      </span>
                      {book.publication_year && (
                        <span>{book.publication_year}</span>
                      )}
                    </div>
                    {book.source_url && (
                      <a
                        href={book.source_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 inline-block text-blue-500 hover:text-blue-700 text-sm"
                      >
                        More information →
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {pagination && pagination.totalPages > 1 && (
              <div className="flex justify-center items-center gap-2">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="px-4 py-2 bg-white border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                >
                  ← Previous
                </button>

                <div className="flex gap-1">
                  {Array.from(
                    { length: Math.min(5, pagination.totalPages) },
                    (_, i) => {
                      const page = i + 1;
                      return (
                        <button
                          key={page}
                          onClick={() => handlePageChange(page)}
                          className={`px-3 py-2 rounded-lg ${
                            page === currentPage
                              ? "bg-blue-500 text-white"
                              : "bg-white border border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          {page}
                        </button>
                      );
                    }
                  )}
                </div>

                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === pagination.totalPages}
                  className="px-4 py-2 bg-white border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                >
                  Next →
                </button>
              </div>
            )}
          </>
        )}

        {/* No Results */}
        {!loading && books.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              No books found
            </h3>
            <p className="text-gray-600 mb-4">
              Try different search terms or click the refresh button to add new
              books.
            </p>
            <button
              onClick={searchNewBooks}
              disabled={isSearching}
              className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 transition-colors disabled:opacity-50"
            >
              {isSearching ? "Searching..." : "🔄 Add new books"}
            </button>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-lg mb-2">📚 Global Library</p>
          <p className="text-gray-400">
            Discover books from around the world - Updated daily with new titles
          </p>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;