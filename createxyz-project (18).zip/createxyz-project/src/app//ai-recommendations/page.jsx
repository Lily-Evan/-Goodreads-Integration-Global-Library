"use client";
import React from "react";

function MainComponent() {
  const [formData, setFormData] = React.useState({
    favoriteGenres: [],
    favoriteAuthors: "",
    booksRead: "",
    mood: "",
    languagePreference: "all",
    numberOfRecommendations: 5,
    additionalPreferences: "",
  });

  const [recommendations, setRecommendations] = React.useState([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [hasSearched, setHasSearched] = React.useState(false);

  const genres = [
    "Fiction",
    "Mystery",
    "Romance",
    "Fantasy",
    "Science Fiction",
    "Thriller",
    "Historical Fiction",
    "Biography",
    "Self-Help",
    "Psychology",
    "Philosophy",
    "Poetry",
    "Drama",
    "Adventure",
    "Classics",
    "Horror",
    "Young Adult",
    "Non-Fiction",
    "Crime",
    "Literary Fiction",
  ];

  const moods = [
    { value: "", label: "Select your mood" },
    { value: "happy", label: "😊 Happy & Uplifting" },
    { value: "sad", label: "😢 Melancholic & Reflective" },
    { value: "adventurous", label: "🗺️ Adventurous & Exciting" },
    { value: "romantic", label: "💕 Romantic & Heartwarming" },
    { value: "mysterious", label: "🔍 Mysterious & Intriguing" },
    { value: "thoughtful", label: "🤔 Thoughtful & Philosophical" },
    { value: "relaxed", label: "😌 Relaxed & Peaceful" },
    { value: "energetic", label: "⚡ Energetic & Fast-paced" },
    { value: "dark", label: "🌙 Dark & Intense" },
    { value: "inspiring", label: "✨ Inspiring & Motivational" },
  ];

  const languages = [
    { value: "all", label: "All Languages" },
    { value: "en", label: "🇺🇸 English" },
    { value: "el", label: "🇬🇷 Greek" },
    { value: "fr", label: "🇫🇷 French" },
    { value: "es", label: "🇪🇸 Spanish" },
    { value: "de", label: "🇩🇪 German" },
  ];

  const handleGenreChange = (genre) => {
    setFormData((prev) => ({
      ...prev,
      favoriteGenres: prev.favoriteGenres.includes(genre)
        ? prev.favoriteGenres.filter((g) => g !== genre)
        : [...prev.favoriteGenres, genre],
    }));
  };

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setHasSearched(true);

    try {
      const requestData = {
        favoriteGenres: formData.favoriteGenres,
        favoriteAuthors: formData.favoriteAuthors
          .split(",")
          .map((a) => a.trim())
          .filter((a) => a),
        booksRead: formData.booksRead
          .split(",")
          .map((b) => b.trim())
          .filter((b) => b),
        mood: formData.mood,
        languagePreference: formData.languagePreference,
        numberOfRecommendations: formData.numberOfRecommendations,
        additionalPreferences: formData.additionalPreferences,
      };

      const response = await fetch("/api/book-recommendations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        throw new Error(`Failed to get recommendations: ${response.status}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setRecommendations(data.recommendations || []);
    } catch (err) {
      console.error(err);
      setError("Could not get recommendations. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getMatchScoreColor = (score) => {
    if (score >= 8) return "text-green-600 bg-green-100";
    if (score >= 6) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  const getLanguageFlag = (lang) => {
    const flags = {
      el: "🇬🇷",
      en: "🇺🇸",
      fr: "🇫🇷",
      es: "🇪🇸",
      de: "🇩🇪",
    };
    return flags[lang] || "🌍";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header */}
      <header className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 font-serif mb-2">
              🤖 AI Book Recommendations
            </h1>
            <p className="text-xl text-gray-600">
              Discover Your Next Great Read
            </p>
            <p className="text-gray-500 mt-2">
              Tell us your preferences and we'll find the perfect books for you
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Preferences Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-4">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                📝 Your Preferences
              </h2>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Favorite Genres */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Favorite Genres
                  </label>
                  <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto">
                    {genres.map((genre) => (
                      <label
                        key={genre}
                        className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-2 rounded"
                      >
                        <input
                          type="checkbox"
                          checked={formData.favoriteGenres.includes(genre)}
                          onChange={() => handleGenreChange(genre)}
                          className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                        />
                        <span className="text-sm text-gray-700">{genre}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Favorite Authors */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Favorite Authors
                  </label>
                  <input
                    type="text"
                    value={formData.favoriteAuthors}
                    onChange={(e) =>
                      handleInputChange("favoriteAuthors", e.target.value)
                    }
                    placeholder="e.g. Stephen King, J.K. Rowling, Agatha Christie"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Separate with commas
                  </p>
                </div>

                {/* Books Read */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Books You've Read
                  </label>
                  <textarea
                    value={formData.booksRead}
                    onChange={(e) =>
                      handleInputChange("booksRead", e.target.value)
                    }
                    placeholder="e.g. Harry Potter, 1984, Pride and Prejudice"
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                {/* Current Mood */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Mood
                  </label>
                  <select
                    value={formData.mood}
                    onChange={(e) => handleInputChange("mood", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {moods.map((mood) => (
                      <option key={mood.value} value={mood.value}>
                        {mood.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Language Preference */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Language Preference
                  </label>
                  <select
                    value={formData.languagePreference}
                    onChange={(e) =>
                      handleInputChange("languagePreference", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {languages.map((lang) => (
                      <option key={lang.value} value={lang.value}>
                        {lang.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Number of Recommendations */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Number of Recommendations:{" "}
                    {formData.numberOfRecommendations}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={formData.numberOfRecommendations}
                    onChange={(e) =>
                      handleInputChange(
                        "numberOfRecommendations",
                        parseInt(e.target.value)
                      )
                    }
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>1</span>
                    <span>10</span>
                  </div>
                </div>

                {/* Additional Preferences */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Additional Preferences
                  </label>
                  <textarea
                    value={formData.additionalPreferences}
                    onChange={(e) =>
                      handleInputChange("additionalPreferences", e.target.value)
                    }
                    placeholder="e.g. I prefer short books, avoid violent content, love plot twists..."
                    rows="3"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 px-6 rounded-lg font-medium hover:from-purple-700 hover:to-pink-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-2"></div>
                      Finding Books...
                    </>
                  ) : (
                    <>🔮 Find My Books!</>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Recommendations Display */}
          <div className="lg:col-span-2">
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <div className="flex items-center">
                  <div className="text-red-500 text-xl mr-3">⚠️</div>
                  <div>
                    <h3 className="text-red-800 font-medium">Error</h3>
                    <p className="text-red-700 text-sm">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {!hasSearched && (
              <div className="text-center py-12">
                <div className="text-8xl mb-4">📚</div>
                <h3 className="text-2xl font-bold text-gray-800 mb-2">
                  Ready for recommendations?
                </h3>
                <p className="text-gray-600 text-lg">
                  Fill out your preferences and discover amazing books!
                </p>
                <p className="text-gray-500 mt-2">
                  Our AI will analyze your tastes and find perfect matches.
                </p>
              </div>
            )}

            {hasSearched &&
              !loading &&
              recommendations.length === 0 &&
              !error && (
                <div className="text-center py-12">
                  <div className="text-6xl mb-4">😔</div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">
                    No recommendations found
                  </h3>
                  <p className="text-gray-600">
                    Try adjusting your preferences or language settings.
                  </p>
                </div>
              )}

            {recommendations.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-800">
                    🎯 Your Personalized Recommendations
                  </h2>
                  <div className="text-sm text-gray-500">
                    {recommendations.length} books found
                  </div>
                </div>

                <div className="space-y-6">
                  {recommendations.map((book, index) => (
                    <div
                      key={book.bookId}
                      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
                    >
                      <div className="flex flex-col md:flex-row">
                        {/* Book Cover */}
                        <div className="md:w-48 h-64 md:h-auto bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center flex-shrink-0">
                          {book.image_url ? (
                            <img
                              src={book.image_url}
                              alt={book.title}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                e.target.style.display = "none";
                                e.target.nextSibling.style.display = "flex";
                              }}
                            />
                          ) : null}
                          <div
                            className="text-6xl text-gray-400"
                            style={{
                              display: book.image_url ? "none" : "flex",
                            }}
                          >
                            📖
                          </div>
                        </div>

                        {/* Book Details */}
                        <div className="flex-1 p-6">
                          <div className="flex items-start justify-between mb-3">
                            <div className="flex-1">
                              <h3 className="text-xl font-bold text-gray-800 mb-1">
                                {book.title}
                              </h3>
                              <p className="text-purple-600 font-medium text-lg">
                                {book.author}
                              </p>
                            </div>
                            <div className="flex items-center space-x-2 ml-4">
                              <span
                                className={`px-3 py-1 rounded-full text-sm font-medium ${getMatchScoreColor(
                                  book.matchScore
                                )}`}
                              >
                                {book.matchScore}/10 ⭐
                              </span>
                              <span className="text-2xl">
                                {getLanguageFlag(book.language)}
                              </span>
                            </div>
                          </div>

                          {book.description && (
                            <p className="text-gray-600 mb-4 line-clamp-3">
                              {book.description}
                            </p>
                          )}

                          {/* AI Reason */}
                          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 mb-4">
                            <h4 className="font-medium text-purple-800 mb-2 flex items-center">
                              🤖 Why I recommend this book:
                            </h4>
                            <p className="text-purple-700 text-sm leading-relaxed">
                              {book.reason}
                            </p>
                          </div>

                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <div className="flex items-center space-x-4">
                              {book.publication_year && (
                                <span>📅 {book.publication_year}</span>
                              )}
                              <span className="bg-gray-100 px-2 py-1 rounded">
                                #{index + 1} Recommendation
                              </span>
                            </div>
                            {book.source_url && (
                              <a
                                href={book.source_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-purple-600 hover:text-purple-800 font-medium"
                              >
                                Learn More →
                              </a>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-lg mb-2">🤖 AI Book Recommendations</p>
          <p className="text-gray-400">
            Discover your perfect books with the power of artificial
            intelligence
          </p>
        </div>
      </footer>

      <style jsx global>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #9333ea, #ec4899);
          cursor: pointer;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #9333ea, #ec4899);
          cursor: pointer;
          border: none;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;